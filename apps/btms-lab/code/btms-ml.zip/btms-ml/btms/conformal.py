"""Split conformal prediction: turn any model's point prediction into an interval with a coverage guarantee.

    q = the ceil((n+1)(1-alpha))-th smallest calibration error |y - f(x)|
    interval = f(x) +/- q,   P(y in interval) >= 1 - alpha   if calibration and test data are exchangeable.

The guarantee is only as honest as the calibration set. Calibrating on rows from the same experiments as the
training rows (random split of a time series) gives intervals that are too narrow for a new material.
`group_calibration` calibrates on whole held-out groups instead.
"""
from __future__ import annotations

import math

import numpy as np


def conformal_quantile(cal_errors: np.ndarray, alpha: float = 0.1) -> float:
    e = np.sort(np.abs(np.asarray(cal_errors)))
    n = len(e)
    k = math.ceil((n + 1) * (1 - alpha))
    if k > n:
        return float("inf")  # too few calibration points for this alpha
    return float(e[k - 1])


def interval(pred: np.ndarray, q: float) -> tuple[np.ndarray, np.ndarray]:
    return pred - q, pred + q


def coverage(y: np.ndarray, lo: np.ndarray, hi: np.ndarray) -> float:
    y = np.asarray(y)
    return float(np.mean((y >= lo) & (y <= hi)))
