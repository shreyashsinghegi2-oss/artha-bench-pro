"""Loading and checking the BTMS dataset, and the PCM property table from the paper.

Dataset format (as in the authors' public file GitHubData_ML.xlsx):
    PCM | Cooling | Time | Location | cooling efficiency(n)

Cooling efficiency (paper, Eq. 4):  eta = (T_max - T) / (T_max - T_min),
with T_max = 59.86 C and T_min = 27.06 C (global extremes of the study).
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

T_MAX_PAPER = 59.86
T_MIN_PAPER = 27.06

COLUMNS = ["pcm", "cooling", "time", "location", "eta"]


@dataclass(frozen=True)
class PCMProps:
    """Thermophysical properties, Mane et al. (2026), Table 2."""

    first_deviation_c: float
    onset_c: float
    latent_j_per_g: float
    rho_liquid: float
    rho_solid: float
    cp_liquid: float  # kJ/(kg K)
    cp_solid: float
    k_liquid: float  # W/(m K)
    k_solid: float


PCM_TABLE: dict[str, PCMProps] = {
    "om42": PCMProps(43.00, 44.64, 223.41, 863, 903, 2.78, 2.71, 0.10, 0.19),
    "om48": PCMProps(48.00, 49.30, 267.95, 875, 960, 2.35, 2.02, 0.10, 0.20),
    "paraffin": PCMProps(59.03, 61.46, 278.43, 778, 861, 2.38, 1.85, 0.15, 0.40),
}

# The numeric PCM codes in the full dataset are NOT documented in the public repository.
# Confirm this mapping with Dr. Mane before using physics features on real data.
DEFAULT_PCM_CODES: dict[int, str] = {0: "none", 1: "paraffin", 2: "om48", 3: "om42"}
DEFAULT_COOLING_CODES: dict[int, str] = {1: "natural", 2: "forced"}

CORE_CELLS = {2, 5}  # C2 and C5 sit in the middle of the module (paper, Section 3.3)


def eta_to_temperature(eta: np.ndarray | pd.Series, t_max: float = T_MAX_PAPER, t_min: float = T_MIN_PAPER):
    """Inverse of Eq. 4, so errors can be reported in degrees Celsius."""
    return t_max - np.asarray(eta) * (t_max - t_min)


def temperature_to_eta(t: np.ndarray | pd.Series, t_max: float = T_MAX_PAPER, t_min: float = T_MIN_PAPER):
    return (t_max - np.asarray(t)) / (t_max - t_min)


def load_excel(path: str | Path) -> pd.DataFrame:
    """Read the authors' Excel format and return standard column names."""
    raw = pd.read_excel(path)
    if raw.shape[1] < 5:
        raise ValueError(f"expected 5 columns (PCM, Cooling, Time, Location, efficiency), got {list(raw.columns)}")
    df = raw.iloc[:, :5].copy()
    df.columns = COLUMNS
    return validate(df)


def validate(df: pd.DataFrame) -> pd.DataFrame:
    missing = [c for c in COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"missing columns: {missing}")
    if df[COLUMNS].isna().any().any():
        raise ValueError("dataset contains empty cells")
    if not df["eta"].between(-0.05, 1.05).all():
        raise ValueError("eta outside [0, 1]: is the efficiency column really Eq. 4?")
    df = df.astype({"pcm": int, "cooling": int, "location": int})
    return df.reset_index(drop=True)


def describe(df: pd.DataFrame) -> str:
    """One-paragraph summary of what the dataset covers (what a reviewer asks first)."""
    configs = df.groupby(["pcm", "cooling"]).size()
    return (
        f"{len(df):,} rows · PCM codes {sorted(df.pcm.unique())} · cooling codes {sorted(df.cooling.unique())} · "
        f"cells {sorted(df.location.unique())} · time {df.time.min()}–{df.time.max()} s · "
        f"{len(configs)} PCM×cooling configurations"
    )
