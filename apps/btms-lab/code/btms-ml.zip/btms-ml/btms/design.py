"""PCM design explorer: which melting point and latent heat would cool this module best?

The paper concludes OM42 performs best because it starts melting earliest, and warns the advantage may
disappear in longer or harder use. This module turns that into a quantitative design question:

  1. Learn the module's physical constants from data with the PINN (btms/pinn.py).
  2. Put them into the lumped energy balance (btms/physics.py, params_from_pinn).
  3. Simulate hypothetical PCMs over a grid of melting points and latent heats, for the 1200 s test and
     for a longer duty cycle, and report the end temperature of the hottest (core) cell.

Results are only as good as the calibrated model: they suggest which materials are worth testing in the lab;
they do not replace the test.
"""
from __future__ import annotations

from dataclasses import replace

import numpy as np
import pandas as pd

from .data import PCM_TABLE, PCMProps
from .physics import LumpedParams, simulate_cell


def hypothetical_pcm(melt_centre_c: float, latent_j_per_g: float, base: str = "om42", spread_c: float = 1.6) -> PCMProps:
    """A material like `base` but melting around `melt_centre_c` with the given latent heat."""
    return replace(PCM_TABLE[base], first_deviation_c=melt_centre_c - spread_c / 2,
                   onset_c=melt_centre_c + spread_c / 2, latent_j_per_g=latent_j_per_g)


AMBIENTS_C = (27.0, 40.0)  # the lab test, and a hot Indian summer day


def sweep(prm: LumpedParams, melt_centres_c, latents_j_per_g, cooling: str = "natural", cell: int = 2,
          durations_s=(1200, 3600), ambients_c=AMBIENTS_C, base: str = "om42") -> pd.DataFrame:
    """Peak temperature of a cell for every (duty cycle, ambient, melting point, latent heat)."""
    rows = []
    for duration in durations_s:
        for amb in ambients_c:
            for centre in melt_centres_c:
                for latent in latents_j_per_g:
                    temp = simulate_cell(hypothetical_pcm(centre, latent, base), cooling, cell, prm,
                                         duration_s=duration, t_amb_c=amb)
                    rows.append({"duration_s": duration, "ambient_c": amb, "melt_centre_c": centre,
                                 "latent_j_per_g": latent, "peak_temp_c": float(temp.max()),
                                 "rise_c": float(temp.max() - amb)})
    return pd.DataFrame(rows)


def robust_best(grid: pd.DataFrame, latent_j_per_g: float) -> pd.DataFrame:
    """For one latent heat and each duty cycle: the melting point whose WORST peak temperature across the
    ambient conditions is lowest. A design must work on a hot day too."""
    g = grid[np.isclose(grid.latent_j_per_g, latent_j_per_g)]
    worst = g.groupby(["duration_s", "melt_centre_c"]).peak_temp_c.max().rename("worst_peak_c").reset_index()
    return worst.loc[worst.groupby("duration_s").worst_peak_c.idxmin()].reset_index(drop=True)


def reference_materials(prm: LumpedParams, cooling: str = "natural", cell: int = 2, durations_s=(1200, 3600),
                        ambients_c=AMBIENTS_C) -> pd.DataFrame:
    rows = []
    for name in ["none", *PCM_TABLE]:
        for duration in durations_s:
            for amb in ambients_c:
                temp = simulate_cell(name, cooling, cell, prm, duration_s=duration, t_amb_c=amb)
                rows.append({"pcm": name, "duration_s": duration, "ambient_c": amb, "peak_temp_c": float(temp.max())})
    return pd.DataFrame(rows)
