"""Which inputs drive the prediction? Permutation importance on held-out data, grouped by feature.

Permutation importance = how much the test error grows when one input column is shuffled. Unlike the
built-in importance of a tree model, it is measured on data the model did not train on, and it works the
same way for every model, so models can be compared.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance


def importance(model, x_test: np.ndarray, y_test: np.ndarray, names: list[str], repeats: int = 5, seed: int = 0,
               max_rows: int = 5000) -> pd.DataFrame:
    if len(x_test) > max_rows:
        idx = np.random.default_rng(seed).choice(len(x_test), max_rows, replace=False)
        x_test, y_test = x_test[idx], y_test[idx]
    r = permutation_importance(model, x_test, y_test, n_repeats=repeats, random_state=seed,
                               scoring="neg_root_mean_squared_error")
    return (pd.DataFrame({"feature": names, "rmse_increase": r.importances_mean, "std": r.importances_std})
            .sort_values("rmse_increase", ascending=False).reset_index(drop=True))
