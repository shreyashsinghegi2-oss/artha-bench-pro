"""Two ways to describe a row to the model.

label    the paper's inputs: PCM code, cooling code, time, cell number. A new PCM is just an unseen code,
         so the model has nothing to reason from.
physics  the PCM is described by its measured properties (Table 2), the cooling mode by a flag and the
         cell by whether it sits in the core. A new PCM is a new point in property space the model can place.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .data import CORE_CELLS, DEFAULT_COOLING_CODES, DEFAULT_PCM_CODES, PCM_TABLE

LABEL_FEATURES = ["pcm", "cooling", "time", "location"]
PHYSICS_FEATURES = [
    "time", "forced", "core_cell", "has_pcm",
    "pcm_first_dev_c", "pcm_onset_c", "pcm_latent", "pcm_k_solid", "pcm_cp_solid", "pcm_rho_solid",
]


def physics_frame(df: pd.DataFrame, pcm_codes: dict[int, str] | None = None,
                  cooling_codes: dict[int, str] | None = None) -> pd.DataFrame:
    pcm_codes = pcm_codes or DEFAULT_PCM_CODES
    cooling_codes = cooling_codes or DEFAULT_COOLING_CODES
    unknown = set(df.pcm.unique()) - set(pcm_codes)
    if unknown:
        raise KeyError(f"PCM codes {sorted(unknown)} have no name: pass pcm_codes (ask Dr. Mane for the coding)")
    names = df.pcm.map(pcm_codes)
    out = pd.DataFrame(index=df.index)
    out["time"] = df.time.astype(float)
    out["forced"] = (df.cooling.map(cooling_codes) == "forced").astype(float)
    out["core_cell"] = df.location.isin(CORE_CELLS).astype(float)
    out["has_pcm"] = (names != "none").astype(float)
    for col, attr in [("pcm_first_dev_c", "first_deviation_c"), ("pcm_onset_c", "onset_c"),
                      ("pcm_latent", "latent_j_per_g"), ("pcm_k_solid", "k_solid"),
                      ("pcm_cp_solid", "cp_solid"), ("pcm_rho_solid", "rho_solid")]:
        out[col] = names.map(lambda n, a=attr: 0.0 if n == "none" else getattr(PCM_TABLE[n], a)).astype(float)
    return out[PHYSICS_FEATURES]


def design_matrix(df: pd.DataFrame, kind: str, **codes) -> np.ndarray:
    if kind == "label":
        return df[LABEL_FEATURES].to_numpy(dtype=float)
    if kind == "physics":
        return physics_frame(df, **codes).to_numpy(dtype=float)
    raise ValueError(kind)
