"""Metrics, computed one way for every model so they can be compared (the paper's R2/RMSE pairs cannot all
come from one test set: on a fixed test set a lower RMSE always means a higher R2)."""
from __future__ import annotations

import numpy as np

from .data import T_MAX_PAPER, T_MIN_PAPER


def r2(y, p) -> float:
    y, p = np.asarray(y), np.asarray(p)
    return float(1 - np.sum((y - p) ** 2) / np.sum((y - y.mean()) ** 2))


def rmse(y, p) -> float:
    return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))


def report(y_eta, p_eta, t_max: float = T_MAX_PAPER, t_min: float = T_MIN_PAPER) -> dict:
    """R2 and RMSE on eta, plus the same error in degrees Celsius (what an engineer actually needs)."""
    span = t_max - t_min
    return {"r2": r2(y_eta, p_eta), "rmse_eta": rmse(y_eta, p_eta), "rmse_c": rmse(y_eta, p_eta) * span,
            "max_abs_c": float(np.max(np.abs(np.asarray(y_eta) - np.asarray(p_eta))) * span)}
