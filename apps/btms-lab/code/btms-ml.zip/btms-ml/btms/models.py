"""The paper's five models, rebuilt in scikit-learn.

Differences from the paper's MATLAB code, stated so nobody is surprised:
- ANN: MATLAB's fitnet(10) trains with Levenberg-Marquardt; scikit-learn has no LM, so the same 10-neuron
  network is trained with L-BFGS (also a second-order-style method).
- SVR: kernel SVR scales with the square of the training rows. On 46,000 rows it is very slow, so it is fitted
  on a random subsample (SVR_MAX_ROWS) and the report says so.
"""
from __future__ import annotations

import numpy as np
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPRegressor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR

SVR_MAX_ROWS = 8000


class SubsampledSVR:
    def __init__(self, seed: int = 0):
        self.seed = seed
        self.model = make_pipeline(StandardScaler(), SVR(kernel="rbf", C=10.0, epsilon=0.005))

    def fit(self, x, y):
        if len(x) > SVR_MAX_ROWS:
            idx = np.random.default_rng(self.seed).choice(len(x), SVR_MAX_ROWS, replace=False)
            x, y = x[idx], y[idx]
        self.model.fit(x, y)
        return self

    def predict(self, x):
        return self.model.predict(x)


def make_models(seed: int = 0) -> dict:
    return {
        "Linear regression": make_pipeline(StandardScaler(), LinearRegression()),
        "Random forest": RandomForestRegressor(n_estimators=100, n_jobs=-1, random_state=seed),
        "SVR (RBF)": SubsampledSVR(seed),
        "Gradient boosting": GradientBoostingRegressor(n_estimators=200, learning_rate=0.1, random_state=seed),
        "ANN 10 neurons": make_pipeline(
            StandardScaler(),
            MLPRegressor(hidden_layer_sizes=(10,), activation="tanh", solver="lbfgs", max_iter=2000, random_state=seed),
        ),
    }
