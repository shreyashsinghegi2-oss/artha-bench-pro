"""A lumped energy-balance model of one cell in the PCM + PHP module.

    C_eff(T) · dT/dt = Q - G · (T - T_amb)

    C_eff(T) = C_cell + m_pcm · [cp + L · melt(T)]      apparent heat capacity method
    melt(T)  = normal density centred in the PCM's melting range (a "mushy zone")
    G        = G_pipe(cooling mode) + g_k · k_pcm        heat-pipe path + conduction through the PCM

Two uses:
1. The physics residual inside the PINN (btms/pinn.py).
2. Generating a SIMULATED dataset with the same shape as the experiment, to test the code before the
   real data arrives. Simulated data must never be reported as a research result.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .data import CORE_CELLS, DEFAULT_COOLING_CODES, DEFAULT_PCM_CODES, PCM_TABLE, PCMProps, temperature_to_eta

PCM = str | PCMProps  # a name from PCM_TABLE, "none", or a hypothetical material


def _props(pcm: PCM) -> PCMProps | None:
    if isinstance(pcm, PCMProps):
        return pcm
    return None if pcm == "none" else PCM_TABLE[pcm]

Q_CELL_W = 2.0  # paper: 2 W per cell (3C discharge of an 18650 cell)
T_AMB_C = 27.0  # paper: still air at 27 C
DURATION_S = 1200  # paper: 1200 s observation window


@dataclass
class LumpedParams:
    c_cell: float = 40.0  # J/K, aluminium substitute cell (about 45 g x 900 J/kg K)
    m_pcm_outer: float = 0.030  # kg of PCM around an outer cell (190 ml shared by 6 cells)
    core_pcm_fraction: float = 0.6  # core cells have less PCM contact (paper, Section 3.3)
    core_extra_heat_w: float = 0.15  # heat received from neighbours by a core cell
    g_pipe: dict[str, float] = field(default_factory=lambda: {"natural": 0.045, "forced": 0.060})  # W/K
    g_per_k: float = 0.10  # W/K added per W/(m K) of PCM conductivity
    melt_width_c: float = 3.0  # spread of the mushy zone
    noise_c: float = 0.05  # thermocouple noise


def melt_density(t_c: np.ndarray, pcm: PCM, width: float) -> np.ndarray:
    """Fraction of latent heat absorbed per kelvin; integrates to 1 over temperature."""
    p = _props(pcm)
    if p is None:
        return np.zeros_like(t_c)
    centre = 0.5 * (p.first_deviation_c + p.onset_c)
    return np.exp(-0.5 * ((t_c - centre) / width) ** 2) / (width * np.sqrt(2 * np.pi))


def heat_capacity(t_c: np.ndarray, pcm: PCM, cell: int, prm: LumpedParams) -> np.ndarray:
    """Apparent heat capacity C_eff(T) of one cell plus its share of PCM, in J/K."""
    p = _props(pcm)
    if p is None:
        return np.full_like(t_c, prm.c_cell, dtype=float)
    m = prm.m_pcm_outer * (prm.core_pcm_fraction if cell in CORE_CELLS else 1.0)
    cp = 1000.0 * p.cp_solid  # J/(kg K)
    latent = 1000.0 * p.latent_j_per_g  # J/kg
    return prm.c_cell + m * (cp + latent * melt_density(t_c, pcm, prm.melt_width_c))


def conductance(pcm: PCM, cooling: str, prm: LumpedParams) -> float:
    p = _props(pcm)
    k = 0.0 if p is None else p.k_solid
    return prm.g_pipe[cooling] + prm.g_per_k * k


def heat_input(cell: int, prm: LumpedParams) -> float:
    return Q_CELL_W + (prm.core_extra_heat_w if cell in CORE_CELLS else 0.0)


def simulate_cell(pcm: PCM, cooling: str, cell: int, prm: LumpedParams, rng: np.random.Generator | None = None,
                  duration_s: int = DURATION_S, t_amb_c: float = T_AMB_C) -> np.ndarray:
    """Temperature (C) at t = 0..duration_s, explicit Euler with 1 s steps.

    The module starts at ambient temperature. On a hot day a low-melting PCM is already molten at the start,
    and the apparent-heat-capacity model then gives it no latent buffer, as in reality.
    """
    t = np.empty(duration_s + 1)
    t[0] = t_amb_c
    q = heat_input(cell, prm)
    g = conductance(pcm, cooling, prm)
    for i in range(duration_s):
        c = heat_capacity(np.array([t[i]]), pcm, cell, prm)[0]
        t[i + 1] = t[i] + (q - g * (t[i] - t_amb_c)) / c
    if rng is not None:
        t = t + rng.normal(0.0, prm.noise_c, size=t.shape)
    return t


def params_from_pinn(constants: dict) -> LumpedParams:
    """Turn the constants a PINN learned from data into a physics model that can simulate new designs."""
    return LumpedParams(
        c_cell=constants["c_cell_J_per_K"],
        m_pcm_outer=constants["m_pcm_kg"],
        core_pcm_fraction=constants["core_pcm_fraction"],
        core_extra_heat_w=constants["core_extra_heat_W"],
        g_pipe={"natural": constants["G_natural_W_per_K"], "forced": constants["G_forced_W_per_K"]},
        g_per_k=constants["G_per_k"],
        melt_width_c=constants["melt_width_C"],
        noise_c=0.0,
    )


def simulated_dataset(prm: LumpedParams | None = None, seed: int = 0) -> pd.DataFrame:
    """SIMULATED stand-in for the experiment: 4 PCM options x 2 cooling modes x 6 cells x 1201 s = 57,648 rows.

    The row count matches the paper by construction. The values come from the model above, not from the lab.
    """
    prm = prm or LumpedParams()
    rng = np.random.default_rng(seed)
    pcm_code = {v: k for k, v in DEFAULT_PCM_CODES.items()}
    cool_code = {v: k for k, v in DEFAULT_COOLING_CODES.items()}
    rows = []
    for pcm in ["none", "paraffin", "om48", "om42"]:
        for cooling in ["natural", "forced"]:
            for cell in range(1, 7):
                temp = simulate_cell(pcm, cooling, cell, prm, rng)
                rows.append(
                    pd.DataFrame(
                        {
                            "pcm": pcm_code[pcm],
                            "cooling": cool_code[cooling],
                            "time": np.arange(DURATION_S + 1),
                            "location": cell,
                            "temp_c": temp,
                        }
                    )
                )
    df = pd.concat(rows, ignore_index=True)
    df["eta"] = temperature_to_eta(df["temp_c"], df["temp_c"].max(), df["temp_c"].min())
    df.attrs["simulated"] = True
    df.attrs["t_max"], df.attrs["t_min"] = float(df["temp_c"].max()), float(df["temp_c"].min())
    return df
