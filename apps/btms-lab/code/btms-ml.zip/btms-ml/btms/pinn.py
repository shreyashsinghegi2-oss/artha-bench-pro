"""Physics-informed neural network for cell temperature, with a lumped energy balance as the physics.

    network:   T_hat(t, x)        x = physics features of the configuration (PCM properties, cooling, core cell)
    data loss: mean (T_hat - T_measured)^2                       on training rows
    physics:   r = C_eff(T_hat) dT_hat/dt - [Q - G (T_hat - T_amb)]   at collocation points, for EVERY configuration
    initial:   T_hat(0, x) = T_amb
    loss       = w_data * L_data + w_phys * mean(r / Q)^2 + w_ic * L_ic

The physical constants (cell heat capacity, PCM mass, pipe conductances, core-cell factors) are learned
from the data together with the network (an inverse problem). They are shared by all PCMs, and each PCM
enters only through its measured properties, so the physics term can be evaluated for a PCM whose
temperatures were never seen. That is what lets a PINN generalise where a pure data model cannot.

Setting w_phys = 0 gives the same network without physics: the fair baseline (as in Vairo et al. 2026).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import torch
from torch import nn

from .data import CORE_CELLS, DEFAULT_COOLING_CODES, DEFAULT_PCM_CODES, PCM_TABLE
from .physics import DURATION_S, Q_CELL_W, T_AMB_C

T_SCALE = 30.0  # temperatures are learned as (T - T_amb) / T_SCALE


@dataclass
class PINNConfig:
    w_data: float = 1.0
    w_phys: float = 1.0
    w_ic: float = 1.0
    steps: int = 3000
    lr: float = 3e-3
    batch: int = 2048
    n_colloc: int = 2048
    hidden: int = 64
    seed: int = 0


def config_table(df: pd.DataFrame, pcm_codes=None, cooling_codes=None) -> pd.DataFrame:
    """One row per (pcm, cooling, location) with the inputs the physics needs."""
    pcm_codes = pcm_codes or DEFAULT_PCM_CODES
    cooling_codes = cooling_codes or DEFAULT_COOLING_CODES
    cfg = df[["pcm", "cooling", "location"]].drop_duplicates().reset_index(drop=True)
    names = cfg.pcm.map(pcm_codes)
    cfg["forced"] = (cfg.cooling.map(cooling_codes) == "forced").astype(float)
    cfg["core"] = cfg.location.isin(CORE_CELLS).astype(float)
    cfg["has_pcm"] = (names != "none").astype(float)
    for col, attr in [("onset", "onset_c"), ("first_dev", "first_deviation_c"), ("latent", "latent_j_per_g"),
                      ("k", "k_solid"), ("cp", "cp_solid")]:
        cfg[col] = names.map(lambda n, a=attr: 0.0 if n == "none" else getattr(PCM_TABLE[n], a)).astype(float)
    return cfg


FEATS = ["forced", "core", "has_pcm", "onset", "first_dev", "latent", "k", "cp"]
FEAT_SCALE = np.array([1, 1, 1, 60, 60, 300, 0.5, 3.0])


class TemperatureNet(nn.Module):
    def __init__(self, n_in: int, hidden: int):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(n_in + 1, hidden), nn.Tanh(), nn.Linear(hidden, hidden), nn.Tanh(),
                                 nn.Linear(hidden, 1))

    def forward(self, t_norm, x):
        return self.net(torch.cat([t_norm, x], dim=1))


class LumpedPhysics(nn.Module):
    """Learnable constants of the energy balance, initialised at physically sensible values."""

    def __init__(self):
        super().__init__()
        self.log_c_cell = nn.Parameter(torch.tensor(np.log(40.0)))
        self.log_m_pcm = nn.Parameter(torch.tensor(np.log(0.03)))
        self.log_g_nat = nn.Parameter(torch.tensor(np.log(0.045)))
        self.log_g_forced = nn.Parameter(torch.tensor(np.log(0.06)))
        self.log_g_per_k = nn.Parameter(torch.tensor(np.log(0.1)))
        self.logit_core_frac = nn.Parameter(torch.tensor(0.4))
        self.log_core_heat = nn.Parameter(torch.tensor(np.log(0.15)))
        self.log_melt_width = nn.Parameter(torch.tensor(np.log(3.0)))

    def residual(self, temp, dtemp_dt, raw):
        """raw columns follow FEATS (unscaled). Returns r / Q, dimensionless."""
        forced, core, has_pcm, onset, first_dev, latent, k, cp = raw.T
        m = torch.exp(self.log_m_pcm) * torch.where(core > 0.5, torch.sigmoid(self.logit_core_frac), torch.ones_like(core))
        width = torch.exp(self.log_melt_width)
        centre = 0.5 * (onset + first_dev)
        melt = torch.exp(-0.5 * ((temp - centre) / width) ** 2) / (width * np.sqrt(2 * np.pi))
        c_eff = torch.exp(self.log_c_cell) + has_pcm * m * (1000.0 * cp + 1000.0 * latent * melt)
        g = torch.where(forced > 0.5, torch.exp(self.log_g_forced), torch.exp(self.log_g_nat)) + torch.exp(self.log_g_per_k) * k
        q = Q_CELL_W + core * torch.exp(self.log_core_heat)
        return (c_eff * dtemp_dt - (q - g * (temp - T_AMB_C))) / Q_CELL_W

    @torch.no_grad()
    def constants(self) -> dict:
        return {
            "c_cell_J_per_K": float(torch.exp(self.log_c_cell)),
            "m_pcm_kg": float(torch.exp(self.log_m_pcm)),
            "G_natural_W_per_K": float(torch.exp(self.log_g_nat)),
            "G_forced_W_per_K": float(torch.exp(self.log_g_forced)),
            "G_per_k": float(torch.exp(self.log_g_per_k)),
            "core_pcm_fraction": float(torch.sigmoid(self.logit_core_frac)),
            "core_extra_heat_W": float(torch.exp(self.log_core_heat)),
            "melt_width_C": float(torch.exp(self.log_melt_width)),
        }


class PINN:
    def __init__(self, cfg: PINNConfig | None = None, pcm_codes=None, cooling_codes=None):
        self.cfg = cfg or PINNConfig()
        self.codes = {"pcm_codes": pcm_codes, "cooling_codes": cooling_codes}

    def _x(self, df):
        table = config_table(df, **self.codes)
        merged = df[["pcm", "cooling", "location"]].merge(table, on=["pcm", "cooling", "location"], how="left")
        raw = merged[FEATS].to_numpy(dtype=np.float32)
        return raw, (raw / FEAT_SCALE).astype(np.float32)

    def fit(self, train: pd.DataFrame, temp_col: str = "temp_c", physics_on: pd.DataFrame | None = None):
        """physics_on: rows whose CONFIGURATIONS get the physics residual (labels never used). Defaults to train."""
        c = self.cfg
        torch.manual_seed(c.seed)
        rng = np.random.default_rng(c.seed)
        raw, x = self._x(train)
        t = (train.time.to_numpy(np.float32) / DURATION_S)[:, None]
        y = ((train[temp_col].to_numpy(np.float32) - T_AMB_C) / T_SCALE)[:, None]
        coll = config_table(physics_on if physics_on is not None else train, **self.codes)
        coll_raw = coll[FEATS].to_numpy(np.float32)
        self.net = TemperatureNet(len(FEATS), c.hidden)
        self.phys = LumpedPhysics()
        opt = torch.optim.Adam(list(self.net.parameters()) + list(self.phys.parameters()), lr=c.lr)
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, c.steps)
        xt, tt, yt = torch.from_numpy(x), torch.from_numpy(t), torch.from_numpy(y)
        for _ in range(c.steps):
            i = torch.from_numpy(rng.integers(0, len(xt), c.batch))
            loss = c.w_data * torch.mean((self.net(tt[i], xt[i]) - yt[i]) ** 2)
            if c.w_phys > 0:
                j = rng.integers(0, len(coll_raw), c.n_colloc)
                craw = torch.from_numpy(coll_raw[j])
                cx = craw / torch.from_numpy(FEAT_SCALE.astype(np.float32))
                ct = torch.from_numpy(rng.uniform(0, 1, (c.n_colloc, 1)).astype(np.float32)).requires_grad_(True)
                out = self.net(ct, cx)
                dout = torch.autograd.grad(out.sum(), ct, create_graph=True)[0]
                temp = T_AMB_C + T_SCALE * out
                dtemp_dt = T_SCALE * dout / DURATION_S  # per second
                r = self.phys.residual(temp.squeeze(1), dtemp_dt.squeeze(1), craw)
                ic = self.net(torch.zeros_like(ct), cx)
                loss = loss + c.w_phys * torch.mean(r ** 2) + c.w_ic * torch.mean(ic ** 2)
            opt.zero_grad()
            loss.backward()
            opt.step()
            sched.step()
        return self

    @torch.no_grad()
    def predict_temperature(self, df: pd.DataFrame) -> np.ndarray:
        _, x = self._x(df)
        t = (df.time.to_numpy(np.float32) / DURATION_S)[:, None]
        return (T_AMB_C + T_SCALE * self.net(torch.from_numpy(t), torch.from_numpy(x))).numpy().ravel()
