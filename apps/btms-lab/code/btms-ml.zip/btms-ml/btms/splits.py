"""Train/test protocols. The question each one answers is what matters.

random            the paper's protocol. Neighbouring seconds of the same experiment land on both sides,
                  so the score measures interpolation inside a curve the model has already seen.
leave_one_pcm     train on all other PCM options, test on the held-out one:
                  "does the model work for a material it has never seen?"
leave_one_config  hold out one PCM x cooling experiment at a time.
future_time       train on the first part of every run, test on the end: "can it extrapolate in time?"
"""
from __future__ import annotations

from collections.abc import Iterator

import numpy as np
import pandas as pd

Split = tuple[np.ndarray, np.ndarray, str]  # train indices, test indices, label


def random_split(df: pd.DataFrame, test_size: float = 0.2, seed: int = 0) -> Iterator[Split]:
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(df))
    n_test = int(round(test_size * len(df)))
    yield np.sort(idx[n_test:]), np.sort(idx[:n_test]), f"random {int(100 * (1 - test_size))}/{int(100 * test_size)}"


def leave_one_group_out(df: pd.DataFrame, by: list[str], skip: set | None = None) -> Iterator[Split]:
    keys = df[by].astype(str).agg("|".join, axis=1)
    for g in sorted(keys.unique()):
        if skip and g in skip:
            continue
        test = np.flatnonzero(keys.values == g)
        train = np.flatnonzero(keys.values != g)
        yield train, test, f"held out {'+'.join(by)}={g}"


def leave_one_pcm(df: pd.DataFrame, include_no_pcm: bool = False) -> Iterator[Split]:
    """Hold out each real PCM in turn. 'No PCM' is usually kept in training: it is a different system."""
    skip = None if include_no_pcm else {"0"}
    yield from leave_one_group_out(df, ["pcm"], skip=skip)


def leave_one_config(df: pd.DataFrame) -> Iterator[Split]:
    yield from leave_one_group_out(df, ["pcm", "cooling"])


def future_time(df: pd.DataFrame, cutoff_s: int = 900) -> Iterator[Split]:
    yield np.flatnonzero(df.time <= cutoff_s), np.flatnonzero(df.time > cutoff_s), f"train t<={cutoff_s}s, test later"


PROTOCOLS = {
    "random": random_split,
    "leave_one_pcm": leave_one_pcm,
    "future_time": future_time,
}
