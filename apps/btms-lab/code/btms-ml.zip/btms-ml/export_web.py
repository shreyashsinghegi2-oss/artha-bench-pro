"""Train the models for the public demo and export them as JSON the browser can run.

    python export_web.py --simulated --out ../web     (or --data data/full.xlsx)

Exports
  model.json    three PINN-style networks (weights + scaling), calibrated physical constants, PCM table
  results.json  experiment metrics (E1-E5) and the design sweep (E7) for the results page
  parity.json   inputs and the PyTorch outputs, so the JavaScript implementation can be tested against them
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from btms.data import DEFAULT_COOLING_CODES, DEFAULT_PCM_CODES, PCM_TABLE, eta_to_temperature, load_excel
from btms.design import robust_best, sweep
from btms.metrics import report
from btms.physics import DURATION_S, Q_CELL_W, T_AMB_C, params_from_pinn, simulated_dataset
from btms.pinn import FEAT_SCALE, FEATS, PINN, T_SCALE, PINNConfig, config_table


def net_to_json(model: PINN) -> dict:
    layers = [m for m in model.net.net if isinstance(m, torch.nn.Linear)]
    return {"layers": [{"W": l.weight.detach().numpy().round(7).tolist(), "b": l.bias.detach().numpy().round(7).tolist()}
                       for l in layers], "activation": "tanh"}


def held_out_report(model: PINN, test: pd.DataFrame, span) -> dict:
    pred_t = model.predict_temperature(test)
    pred_eta = (span[0] - pred_t) / (span[0] - span[1])
    r = report(test.eta.to_numpy(), pred_eta, *span)
    return {k: round(v, 4) for k, v in r.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data")
    ap.add_argument("--simulated", action="store_true")
    ap.add_argument("--out", default="web")
    ap.add_argument("--steps", type=int, default=3000)
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    if a.simulated:
        df = simulated_dataset()
        span = (df.attrs["t_max"], df.attrs["t_min"])
        data_note = "SIMULATED data from a lumped energy-balance model (pipeline demonstration, not experimental results)"
    else:
        df = load_excel(a.data)
        df["temp_c"] = eta_to_temperature(df.eta)
        span = (59.86, 27.06)
        data_note = f"Experimental data: {a.data}"

    om42 = [c for c, n in DEFAULT_PCM_CODES.items() if n == "om42"][0]
    train, test = df[df.pcm != om42], df[df.pcm == om42]
    cfg = PINNConfig(steps=a.steps)
    models = {
        "pinn_all": PINN(cfg).fit(df, physics_on=df),
        "pinn_unseen_om42": PINN(cfg).fit(train, physics_on=df),
        "nn_unseen_om42": PINN(PINNConfig(steps=a.steps, w_phys=0.0)).fit(train, physics_on=df),
    }
    held = {k: held_out_report(m, test, span) for k, m in models.items() if k != "pinn_all"}
    constants = models["pinn_all"].phys.constants()

    model_json = {
        "data_note": data_note,
        "feats": FEATS, "feat_scale": FEAT_SCALE.tolist(), "t_scale": T_SCALE, "t_amb": T_AMB_C, "duration_s": DURATION_S,
        "q_cell_w": Q_CELL_W, "span": list(span),
        "pcm_table": {k: vars(v) for k, v in PCM_TABLE.items()},
        "pcm_codes": DEFAULT_PCM_CODES, "cooling_codes": DEFAULT_COOLING_CODES,
        "constants": constants,
        "models": {k: net_to_json(m) for k, m in models.items()},
        "held_out_om42": held,
    }
    (out / "model.json").write_text(json.dumps(model_json, separators=(",", ":")))

    # parity vectors: every configuration at a few times
    cfgs = config_table(df)
    sample = cfgs.loc[cfgs.index.repeat(4)].reset_index(drop=True)
    sample["time"] = np.tile([0, 300, 750, 1200], len(cfgs))
    parity = {k: {"rows": sample[["pcm", "cooling", "location", "time"]].to_dict("records"),
                  "temp_c": np.round(m.predict_temperature(sample), 6).tolist()} for k, m in models.items()}
    (out / "parity.json").write_text(json.dumps(parity, separators=(",", ":")))

    # results page data
    res = {"data_note": data_note, "held_out_om42": held, "constants": constants}
    metrics = Path("results/metrics.csv")
    if metrics.exists():
        m = pd.read_csv(metrics)
        res["experiments"] = (m.groupby(["experiment", "features", "model"])[["r2", "rmse_c", "max_abs_c"]].mean()
                              .round(4).reset_index().to_dict("records"))
    conf = Path("results/conformal.csv")
    if conf.exists():
        res["conformal"] = pd.read_csv(conf).groupby("calibration")[["half_width_C", "coverage"]].mean().round(3).reset_index().to_dict("records")
    prm = params_from_pinn(constants)
    grid = sweep(prm, np.arange(30.0, 66.1, 2.0), [250.0])
    res["design_grid"] = grid.round(3).to_dict("records")
    res["design_best"] = robust_best(grid, 250.0).round(3).to_dict("records")
    (out / "results.json").write_text(json.dumps(res, separators=(",", ":")))
    print(json.dumps({"held_out_om42": held, "constants": constants}, indent=2))


if __name__ == "__main__":
    main()
