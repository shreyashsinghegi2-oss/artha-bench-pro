# Explainability and PCM design

**Data:** SIMULATED data (pipeline test only, not a research result)

57,648 rows · PCM codes [np.int64(0), np.int64(1), np.int64(2), np.int64(3)] · cooling codes [np.int64(1), np.int64(2)] · cells [np.int64(1), np.int64(2), np.int64(3), np.int64(4), np.int64(5), np.int64(6)] · time 0–1200 s · 8 PCM×cooling configurations

## E6 What drives the prediction (gradient boosting, train t<=900s, test later)

Paper inputs:

| feature   |   rmse_increase |    std |
|:----------|----------------:|-------:|
| pcm       |          0.2183 | 0.002  |
| location  |          0.0182 | 0.0001 |
| cooling   |          0.0161 | 0.0003 |
| time      |          0      | 0      |

Physics inputs:

| feature         |   rmse_increase |    std |
|:----------------|----------------:|-------:|
| pcm_cp_solid    |          0.1113 | 0.0011 |
| core_cell       |          0.0199 | 0.0001 |
| pcm_first_dev_c |          0.0176 | 0.0003 |
| forced          |          0.0168 | 0.0003 |
| pcm_onset_c     |          0.0141 | 0.0003 |
| pcm_rho_solid   |          0.011  | 0.0002 |
| pcm_k_solid     |          0.0087 | 0.0002 |
| pcm_latent      |          0.0019 | 0      |
| has_pcm         |          0.0017 | 0      |
| time            |          0      | 0      |

## E7 Constants learned from the data by the PINN

```json
{
  "c_cell_J_per_K": 42.09922931586187,
  "m_pcm_kg": 0.028833873108574055,
  "G_natural_W_per_K": 0.048295982711484366,
  "G_forced_W_per_K": 0.05214199761747277,
  "G_per_k": 0.10129589884825113,
  "core_pcm_fraction": 0.6637469530105591,
  "core_extra_heat_W": 0.08410714084671157,
  "melt_width_C": 2.674266022102954
}
```

## Reference materials in the calibrated model (core cell, natural convection)

| pcm      |   duration_s |   ambient_c |   peak_temp_c |
|:---------|-------------:|------------:|--------------:|
| none     |         1200 |          27 |         59.27 |
| none     |         1200 |          40 |         72.27 |
| none     |         3600 |          27 |         69.46 |
| none     |         3600 |          40 |         82.46 |
| om42     |         1200 |          27 |         40.6  |
| om42     |         1200 |          40 |         44.02 |
| om42     |         3600 |          27 |         44.5  |
| om42     |         3600 |          40 |         59.46 |
| om48     |         1200 |          27 |         44.08 |
| om48     |         1200 |          40 |         47.2  |
| om48     |         3600 |          27 |         47.6  |
| om48     |         3600 |          40 |         51.94 |
| paraffin |         1200 |          27 |         44.54 |
| paraffin |         1200 |          40 |         55.51 |
| paraffin |         3600 |          27 |         50.09 |
| paraffin |         3600 |          40 |         58.39 |

## Robust best melting point at 250 J/g (lowest worst-case peak over ambients 27 and 40 °C)

|   duration_s |   melt_centre_c |   worst_peak_c |
|-------------:|----------------:|---------------:|
|         1200 |              42 |          43.11 |
|         3600 |              48 |          52.19 |

These designs come from a model calibrated on the data. They suggest which materials are worth testing; only an experiment can confirm them.
