# Results

**Data:** SIMULATED data from btms/physics.py (pipeline test only, not a research result)

57,648 rows · PCM codes [np.int64(0), np.int64(1), np.int64(2), np.int64(3)] · cooling codes [np.int64(1), np.int64(2)] · cells [np.int64(1), np.int64(2), np.int64(3), np.int64(4), np.int64(5), np.int64(6)] · time 0–1200 s · 8 PCM×cooling configurations

## Mean over splits

| experiment                             | features   | model                 |      r2 |   rmse_c |   max_abs_c |
|:---------------------------------------|:-----------|:----------------------|--------:|---------:|------------:|
| E1 reproduce (random split)            | label      | ANN 10 neurons        |  0.9748 |     1.18 |        3.13 |
| E1 reproduce (random split)            | label      | Gradient boosting     |  0.9991 |     0.23 |        1.01 |
| E1 reproduce (random split)            | label      | Linear regression     |  0.7744 |     3.54 |        9.15 |
| E1 reproduce (random split)            | label      | Random forest         |  0.9999 |     0.06 |        0.27 |
| E1 reproduce (random split)            | label      | SVR (RBF)             |  0.9998 |     0.1  |        0.34 |
| E2 future time                         | label      | ANN 10 neurons        |  0.8982 |     2.24 |        7.67 |
| E2 future time                         | label      | Gradient boosting     |  0.9453 |     1.64 |        5.37 |
| E2 future time                         | label      | Linear regression     |  0.3792 |     5.53 |       10.24 |
| E2 future time                         | label      | Random forest         |  0.9506 |     1.56 |        5.06 |
| E2 future time                         | label      | SVR (RBF)             |  0.9629 |     1.35 |        5.79 |
| E2 leave-one-PCM-out                   | label      | ANN 10 neurons        |  0.0464 |     4.02 |        6.99 |
| E2 leave-one-PCM-out                   | label      | Gradient boosting     | -0.818  |     4.35 |        7.63 |
| E2 leave-one-PCM-out                   | label      | Linear regression     | -0.2386 |     4.33 |        7.98 |
| E2 leave-one-PCM-out                   | label      | Random forest         | -0.8175 |     4.36 |        7.67 |
| E2 leave-one-PCM-out                   | label      | SVR (RBF)             | -0.112  |     4.67 |        7.57 |
| E3 physics features, leave-one-PCM-out | physics    | ANN 10 neurons        | -2.9133 |     8.04 |       13.2  |
| E3 physics features, leave-one-PCM-out | physics    | Gradient boosting     |  0.8821 |     1.16 |        2.8  |
| E3 physics features, leave-one-PCM-out | physics    | Linear regression     |  0.6999 |     2.14 |        4.78 |
| E3 physics features, leave-one-PCM-out | physics    | Random forest         |  0.8743 |     1.27 |        2.89 |
| E3 physics features, leave-one-PCM-out | physics    | SVR (RBF)             |  0.8635 |     1.6  |        3.48 |
| E4 PINN, leave-one-PCM-out             | physics    | NN, no physics        |  0.8266 |     1.38 |        3.09 |
| E4 PINN, leave-one-PCM-out             | physics    | PINN (energy balance) |  0.9777 |     0.61 |        1.85 |

## 90% conformal intervals (gradient boosting, physics features, held-out PCM as test)

| calibration   |   half_width_C |   coverage |
|:--------------|---------------:|-----------:|
| held-out PCM  |          2.277 |      0.64  |
| random rows   |          0.265 |      0.306 |

Target coverage: 0.90.
