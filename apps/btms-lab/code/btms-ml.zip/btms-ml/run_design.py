"""E6 explainability and E7 PCM design exploration. Writes results/DESIGN.md and two figures.

    python run_design.py --simulated
    python run_design.py --data data/full.xlsx

E6  Which inputs drive the prediction? Permutation importance on a held-out PCM, paper inputs vs physics inputs.
E7  Which PCM would cool best? Calibrate the energy balance on the data with the PINN, then simulate hypothetical
    materials (melting point x latent heat) for the 1200 s test and a 3600 s duty cycle.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from btms.data import describe, eta_to_temperature, load_excel
from btms.design import reference_materials, robust_best, sweep
from btms.explain import importance
from btms.features import LABEL_FEATURES, PHYSICS_FEATURES, design_matrix
from btms.models import make_models
from btms.physics import params_from_pinn, simulated_dataset
from btms.pinn import PINN, PINNConfig
from btms.splits import future_time

OUT = Path("results")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data")
    ap.add_argument("--simulated", action="store_true")
    ap.add_argument("--steps", type=int, default=3000)
    a = ap.parse_args()
    if a.simulated == bool(a.data):
        ap.error("choose exactly one of --data or --simulated")
    OUT.mkdir(exist_ok=True)
    if a.simulated:
        df = simulated_dataset()
        source = "SIMULATED data (pipeline test only, not a research result)"
    else:
        df = load_excel(a.data)
        df["temp_c"] = eta_to_temperature(df.eta)
        source = a.data

    # E6: permutation importance on the last part of every run (all PCMs present, so PCM inputs can matter;
    # a single held-out PCM would make its properties constant and their importance zero by construction)
    train, test, label = next(iter(future_time(df)))
    y = df.eta.to_numpy()
    imp = {}
    for kind, names in [("label", LABEL_FEATURES), ("physics", PHYSICS_FEATURES)]:
        x = design_matrix(df, kind)
        model = make_models()["Gradient boosting"].fit(x[train], y[train])
        imp[kind] = importance(model, x[test], y[test], names)

    # E7: calibrate on all data, then explore designs with the calibrated physics
    pinn = PINN(PINNConfig(steps=a.steps)).fit(df, physics_on=df)
    constants = pinn.phys.constants()
    (OUT / "calibrated_constants.json").write_text(json.dumps(constants, indent=2))
    prm = params_from_pinn(constants)
    centres = np.arange(30.0, 66.1, 2.0)
    latents = np.array([150.0, 200.0, 250.0, 300.0])
    grid = sweep(prm, centres, latents)
    grid.to_csv(OUT / "design_grid.csv", index=False)
    best = robust_best(grid, 250.0)
    ref = reference_materials(prm)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4), sharey=True)
    for ax, duration in zip(axes, (1200, 3600)):
        for amb, style in [(27.0, "-"), (40.0, "--")]:
            g = grid[(grid.duration_s == duration) & (grid.latent_j_per_g == 250.0) & (grid.ambient_c == amb)]
            ax.plot(g.melt_centre_c, g.peak_temp_c, style, marker="o", ms=3, label=f"ambient {amb:.0f} °C")
        b = best[best.duration_s == duration]
        ax.axvline(float(b.melt_centre_c.iloc[0]), color="grey", lw=1, ls=":")
        ax.set_title(f"{duration} s of 3C-equivalent heating, 250 J/g")
        ax.set_xlabel("PCM melting point (°C, centre of melting range)")
        ax.grid(alpha=0.3)
    axes[0].set_ylabel("Peak temperature of core cell (°C)")
    axes[1].legend(fontsize=8)
    fig.suptitle("Calibrated energy balance: which melting point keeps the hottest cell coolest?")
    fig.tight_layout()
    fig.savefig(OUT / "design_melting_point.png", dpi=150)

    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    for ax, kind in zip(axes, ("label", "physics")):
        d = imp[kind].iloc[::-1]
        ax.barh(d.feature, d.rmse_increase, xerr=d["std"], color="#3b6ea5")
        ax.set_title(f"{kind} inputs ({label})")
        ax.set_xlabel("RMSE increase when shuffled")
    fig.tight_layout()
    fig.savefig(OUT / "importance.png", dpi=150)

    (OUT / "DESIGN.md").write_text(
        f"# Explainability and PCM design\n\n**Data:** {source}\n\n{describe(df)}\n\n"
        f"## E6 What drives the prediction (gradient boosting, {label})\n\n"
        f"Paper inputs:\n\n{imp['label'].round(4).to_markdown(index=False)}\n\n"
        f"Physics inputs:\n\n{imp['physics'].round(4).to_markdown(index=False)}\n\n"
        "**How to read this.** With only three PCMs, every PCM property is a perfect stand-in for the others, so "
        "importance is shared among them arbitrarily: the data cannot say *which* property matters. Separating "
        "melting point, latent heat and conductivity needs more materials. Time shows zero importance here because "
        "every test time lies beyond the training range, where tree models predict a constant.\n\n"
        f"## E7 Constants learned from the data by the PINN\n\n```json\n{json.dumps(constants, indent=2)}\n```\n\n"
        f"## Reference materials in the calibrated model (core cell, natural convection)\n\n"
        f"{ref.round(2).to_markdown(index=False)}\n\n"
        f"## Robust best melting point at 250 J/g (lowest worst-case peak over ambients 27 and 40 °C)\n\n"
        f"{best.round(2).to_markdown(index=False)}\n\n"
        "These designs come from a model calibrated on the data. They suggest which materials are worth testing; "
        "only an experiment can confirm them.\n"
    )
    print((OUT / "DESIGN.md").read_text())


if __name__ == "__main__":
    main()
