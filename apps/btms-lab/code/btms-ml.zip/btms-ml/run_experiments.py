"""Run the full study and write results/RESULTS.md, results/metrics.csv and figures.

    python run_experiments.py --simulated            # test the pipeline on simulated data (NOT research results)
    python run_experiments.py --data data/full.xlsx  # the real 57,648-row dataset from Dr. Mane

Experiments
  E1  Reproduce: the paper's 5 models with its random split and its inputs.
  E2  Honest test: the same models, leave-one-PCM-out and future-time protocols.
  E3  Physics features: replace the PCM code with the PCM's measured properties.
  E4  PINN: same network with and without the energy-balance loss, leave-one-PCM-out.
  E5  Uncertainty: 90% conformal intervals, calibrated randomly vs on a held-out PCM; check coverage.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from btms.conformal import conformal_quantile, coverage, interval
from btms.data import DEFAULT_PCM_CODES, describe, eta_to_temperature, load_excel
from btms.features import design_matrix
from btms.metrics import report
from btms.models import make_models
from btms.physics import simulated_dataset
from btms.pinn import PINN, PINNConfig
from btms.splits import future_time, leave_one_pcm, random_split

OUT = Path("results")


def run_models(df, split_iter, feature_kind, protocol, span, rows, models=None):
    for train, test, label in split_iter:
        x = design_matrix(df, feature_kind)
        y = df.eta.to_numpy()
        for name, model in (models or make_models()).items():
            t0 = time.time()
            model.fit(x[train], y[train])
            pred = model.predict(x[test])
            rows.append({"experiment": protocol, "split": label, "features": feature_kind, "model": name,
                         **report(y[test], pred, *span), "seconds": round(time.time() - t0, 1)})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", help="Excel file in the authors' format")
    ap.add_argument("--simulated", action="store_true")
    ap.add_argument("--fast", action="store_true", help="fewer PINN steps, for a quick check")
    a = ap.parse_args()
    if a.simulated == bool(a.data):
        ap.error("choose exactly one of --data or --simulated")
    OUT.mkdir(exist_ok=True)

    if a.simulated:
        df = simulated_dataset()
        span = (df.attrs["t_max"], df.attrs["t_min"])
        source = "SIMULATED data from btms/physics.py (pipeline test only, not a research result)"
    else:
        df = load_excel(a.data)
        span = (59.86, 27.06)
        df["temp_c"] = eta_to_temperature(df.eta)
        source = f"{a.data}"
    if df.pcm.nunique() < 2:
        raise SystemExit(f"Only one PCM in this file ({describe(df)}). The study needs the full dataset.")

    rows: list[dict] = []
    # E1, E2 with the paper's inputs
    run_models(df, random_split(df, 0.2), "label", "E1 reproduce (random split)", span, rows)
    run_models(df, leave_one_pcm(df), "label", "E2 leave-one-PCM-out", span, rows)
    run_models(df, future_time(df), "label", "E2 future time", span, rows)
    # E3 physics features, same honest protocol
    run_models(df, leave_one_pcm(df), "physics", "E3 physics features, leave-one-PCM-out", span, rows)

    # E4 PINN vs the same network without physics
    steps = 600 if a.fast else 3000
    for train, test, label in leave_one_pcm(df):
        tr, te = df.iloc[train], df.iloc[test]
        for name, w in [("NN, no physics", 0.0), ("PINN (energy balance)", 1.0)]:
            t0 = time.time()
            m = PINN(PINNConfig(w_phys=w, steps=steps)).fit(tr, physics_on=df)  # physics may see the held-out
            pred_t = m.predict_temperature(te)                                   # configuration, never its labels
            pred_eta = (span[0] - pred_t) / (span[0] - span[1])
            rows.append({"experiment": "E4 PINN, leave-one-PCM-out", "split": label, "features": "physics",
                         "model": name, **report(te.eta.to_numpy(), pred_eta, *span),
                         "seconds": round(time.time() - t0, 1)})
            if w > 0:
                (OUT / f"pinn_constants_{label.split('=')[-1]}.json").write_text(json.dumps(m.phys.constants(), indent=2))

    # E5 conformal intervals for gradient boosting with physics features
    cov_rows = []
    x = design_matrix(df, "physics")
    y = df.eta.to_numpy()
    for train, test, label in leave_one_pcm(df):
        rest = np.setdiff1d(np.arange(len(df)), test)
        held = df.iloc[rest].pcm.unique()
        for calib in ["random rows", "held-out PCM"]:
            if calib == "random rows":
                rng = np.random.default_rng(0)
                cal = rng.choice(rest, size=len(rest) // 5, replace=False)
            else:
                cal_pcm = [p for p in held if p != 0][0]
                cal = rest[df.iloc[rest].pcm.to_numpy() == cal_pcm]
            fit_idx = np.setdiff1d(rest, cal)
            model = make_models()["Gradient boosting"].fit(x[fit_idx], y[fit_idx])
            q = conformal_quantile(y[cal] - model.predict(x[cal]), alpha=0.1)
            lo, hi = interval(model.predict(x[test]), q)
            cov_rows.append({"split": label, "calibration": calib, "half_width_C": q * (span[0] - span[1]),
                             "coverage": coverage(y[test], lo, hi)})

    res = pd.DataFrame(rows)
    cov = pd.DataFrame(cov_rows)
    res.to_csv(OUT / "metrics.csv", index=False)
    cov.to_csv(OUT / "conformal.csv", index=False)

    summary = (res.groupby(["experiment", "features", "model"])[["r2", "rmse_c", "max_abs_c"]].mean()
               .round({"r2": 4, "rmse_c": 2, "max_abs_c": 2}).reset_index())
    cov_summary = cov.groupby("calibration")[["half_width_C", "coverage"]].mean().round(3).reset_index()

    fig, ax = plt.subplots(figsize=(8, 4.5))
    for exp, marker in [("E1 reproduce (random split)", "o"), ("E2 leave-one-PCM-out", "s"),
                        ("E3 physics features, leave-one-PCM-out", "^")]:
        s = summary[summary.experiment == exp]
        ax.scatter(s.model, s.rmse_c, label=exp, marker=marker, s=60)
    ax.set_ylabel("RMSE (°C), lower is better")
    ax.set_title("Same models, different questions: random split vs unseen PCM")
    ax.tick_params(axis="x", rotation=20)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(OUT / "protocol_comparison.png", dpi=150)

    (OUT / "RESULTS.md").write_text(
        f"# Results\n\n**Data:** {source}\n\n{describe(df)}\n\n"
        f"## Mean over splits\n\n{summary.to_markdown(index=False)}\n\n"
        f"## 90% conformal intervals (gradient boosting, physics features, held-out PCM as test)\n\n"
        f"{cov_summary.to_markdown(index=False)}\n\nTarget coverage: 0.90.\n"
    )
    print((OUT / "RESULTS.md").read_text())


if __name__ == "__main__":
    main()
