import numpy as np
import pytest

from btms.conformal import conformal_quantile, coverage, interval
from btms.data import eta_to_temperature, load_excel, temperature_to_eta
from btms.features import design_matrix, physics_frame
from btms.metrics import r2, rmse
from btms.physics import LumpedParams, heat_capacity, melt_density, simulate_cell, simulated_dataset
from btms.splits import future_time, leave_one_pcm, random_split


@pytest.fixture(scope="module")
def sim():
    return simulated_dataset()


def test_public_sample_loads():
    df = load_excel("data/GitHubData_ML.xlsx")
    assert len(df) == 100 and df.pcm.nunique() == 1  # the public file is only a 100-row sample


def test_eta_round_trip():
    t = np.array([27.06, 40.0, 59.86])
    assert np.allclose(eta_to_temperature(temperature_to_eta(t)), t)
    assert np.allclose(temperature_to_eta([59.86, 27.06]), [0, 1])


def test_simulated_shape_matches_paper(sim):
    assert len(sim) == 4 * 2 * 6 * 1201 == 57_648


def test_no_cooling_rise_is_q_t_over_c():
    prm = LumpedParams(g_pipe={"natural": 0.0, "forced": 0.0}, noise_c=0.0)
    rise = simulate_cell("none", "natural", 1, prm)[-1] - 27.0
    assert rise == pytest.approx(2.0 * 1200 / prm.c_cell, rel=1e-9)


def test_melt_density_integrates_to_one():
    t = np.linspace(0, 120, 200_001)
    assert np.trapezoid(melt_density(t, "om42", 3.0), t) == pytest.approx(1.0, abs=1e-6)
    assert heat_capacity(np.array([44.0]), "om42", 1, LumpedParams())[0] > heat_capacity(np.array([30.0]), "om42", 1, LumpedParams())[0]


def test_pcm_cools_better_than_none():
    prm = LumpedParams(noise_c=0.0)
    assert simulate_cell("om42", "natural", 1, prm)[-1] < simulate_cell("none", "natural", 1, prm)[-1]


def test_splits_disjoint_and_groups_held_out(sim):
    for tr, te, _ in list(random_split(sim)) + list(leave_one_pcm(sim)) + list(future_time(sim)):
        assert len(np.intersect1d(tr, te)) == 0 and len(tr) + len(te) == len(sim)
    for tr, te, _ in leave_one_pcm(sim):
        assert set(sim.iloc[te].pcm.unique()).isdisjoint(sim.iloc[tr].pcm.unique())


def test_physics_features(sim):
    f = physics_frame(sim)
    assert (f.loc[sim.pcm == 0, "pcm_latent"] == 0).all()
    assert design_matrix(sim, "label").shape == (len(sim), 4)
    with pytest.raises(KeyError):
        physics_frame(sim.assign(pcm=9))


def test_conformal_covers_on_exchangeable_data():
    rng = np.random.default_rng(1)
    cal, test = rng.normal(size=2000), rng.normal(size=20000)
    q = conformal_quantile(cal, alpha=0.1)
    assert 0.88 <= coverage(test, *interval(np.zeros_like(test), q)) <= 0.92


def test_metrics():
    assert r2([1, 2, 3], [1, 2, 3]) == 1.0 and rmse([0, 0], [3, 4]) == pytest.approx(np.sqrt(12.5))


def test_hot_day_melts_low_pcm_before_start():
    from btms.design import hypothetical_pcm
    prm = LumpedParams(noise_c=0.0)
    low = hypothetical_pcm(34.0, 250.0)
    mild = simulate_cell(low, "natural", 2, prm, t_amb_c=27.0)
    hot = simulate_cell(low, "natural", 2, prm, t_amb_c=40.0)
    assert hot.max() - 40.0 > mild.max() - 27.0  # no latent buffer left when it starts molten


def test_robust_best_picks_worst_case_minimum():
    import pandas as pd
    from btms.design import robust_best
    grid = pd.DataFrame({"duration_s": [1200] * 4, "melt_centre_c": [40, 40, 50, 50], "ambient_c": [27, 40, 27, 40],
                         "latent_j_per_g": [250.0] * 4, "peak_temp_c": [38, 60, 45, 50]})
    assert float(robust_best(grid, 250.0).melt_centre_c.iloc[0]) == 50
